package userdao;

public class UserDAO {
	
public boolean isValidCredentials(String UserID,String password )
{ 
	if(UserID.equals("NIIT")&& password.equals("NIIT@123"))
	{
		return true;
		
	}
	else
	{
		return false;
	}
}
}
