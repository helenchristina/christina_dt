package h2example;



import java.sql.*;
public class SimpleJDBCTest { 
   public static void main(String[] args) {
       String url = "jdbc:h2:tcp://localhost/~/test";
       String username = "sa";
       String password = "";
       String query = "SELECT * FROM HELEN";
       try (Connection con = 
           
    		   DriverManager.getConnection (url, username, password);
            Statement stmt = con.createStatement ( );
    		 
ResultSet rs = stmt.executeQuery (query)) {
         while (rs.next()) {
             int empID = rs.getInt("ID");
             String first = rs.getString("First_Name");
             String last = rs.getString("Last_Name");
             Date birthDate = rs.getDate("BirthDate");
             float salary = rs.getFloat("Salary");
             System.out.println("Employee ID:   " + empID + "\n"
             + "Employee Name: " + first + " " + last + "\n"
             + "Birth Date:    " + birthDate + "\n"
             + "Salary:        " + salary);
         } // end of while
     } catch (SQLException e) {
         System.out.println("SQL Exception: " + e);
     } // end of try-with-resources
  } }
