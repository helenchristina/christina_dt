package h2example;


import java.sql.*;
public class Update {
 
    public static void main(String[] args) {
         
        Connection con;
        Statement stmt;
        try {
            
            con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
            
            stmt = con.createStatement();
            stmt.execute("UPDATE HELEN SET SALARY=26799 WHERE ID=9");

    
            System.out.println("Updated queries: ");
         } 
        catch (SQLException e) {
            e.printStackTrace();
        
        }
    }
}


