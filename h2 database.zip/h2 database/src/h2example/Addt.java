package h2example;

import java.sql.*;
public class Addt {
	

	  
	    public static void main(String[] args) {
	        Connection connection; 
	        Statement stmt;
	        try
	        {
	        	  
	            connection = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
	             
	            stmt = connection.createStatement();
	            stmt.execute("INSERT INTO HELEN (ID,FIRST_NAME,LAST_NAME,BIRTHDATE,SALARY)"
	                                + "VALUES ('9','Lokesh','Gupta','1994-11-08','7688')");
	            System.out.println("inserted successfully");
	        } 
	        catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
}
