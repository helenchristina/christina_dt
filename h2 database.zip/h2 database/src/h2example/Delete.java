package h2example;
import java.sql.*;
public class Delete {
	    public static void main(String[] args) {
	    	
	    	Connection   connection;
	    	Statement    stmt;
	        try
	        {
	            
	            connection = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
	             
	            stmt = connection.createStatement();
	            stmt.execute("DELETE FROM HELEN WHERE ID = 3");
	            System.out.println("delete succesfully");
	        } 
	        catch (Exception e) {
	            e.printStackTrace();
	        }
	        }
	    }   


