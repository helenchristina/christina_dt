package com.niit.shopingcartt.model;

public class UtilClass {
public String replace(String st,String ch1,String ch2)
{
	return st.replace(ch1,ch2);
}
public static void main(String arg[])
{
	UtilClass util=new UtilClass();
	String u=util.replace(",prd",",","");
	System.out.println(u);
}
}

