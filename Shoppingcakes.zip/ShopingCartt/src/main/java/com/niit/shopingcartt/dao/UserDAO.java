package com.niit.shopingcartt.dao;

import org.springframework.stereotype.Repository;

@Repository
public class UserDAO {
	

	
	public String isValidUser(String userName, String password)
	{
		if(userName.equals("helen")  && password.equals("NIIT")	)
		{
			return "admin";
		}
		else if(userName.equals("cool")  && password.equals("NIIT")	)
		{
			return "user";
		}
		else
		{
			return "none";
			
		}
	}




}
